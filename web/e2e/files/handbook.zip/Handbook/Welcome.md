# Welcome

How the team works.
